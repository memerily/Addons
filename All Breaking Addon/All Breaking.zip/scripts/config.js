const axe = [
  'minecraft:wooden_axe',
  'minecraft:stone_axe',
  'minecraft:iron_axe',
  'minecraft:golden_axe',
  'minecraft:diamond_axe',
  'minecraft:netherite_axe'
]
const pickaxe_tier_1 = [
  'minecraft:wooden_pickaxe',
  'minecraft:stone_pickaxe',
  'minecraft:iron_pickaxe',
  'minecraft:golden_pickaxe',
  'minecraft:diamond_pickaxe',
  'minecraft:netherite_pickaxe'
]
const pickaxe_tier_2 = [
  'minecraft:stone_pickaxe',
  'minecraft:iron_pickaxe',
  'minecraft:diamond_pickaxe',
  'minecraft:netherite_pickaxe'
]
const pickaxe_tier_3 = [
  'minecraft:iron_pickaxe',
  'minecraft:diamond_pickaxe',
  'minecraft:netherite_pickaxe'
]
const pickaxe_tier_4 = [
  'minecraft:diamond_pickaxe',
  'minecraft:netherite_pickaxe'
]

const block_config = {
  blocks: [
    {
      id: "minecraft:log", // blockID
      data: [0, 4, 8], // データ値を指定 ない場合0
      type: "log", // 壊れ方の設定 modeを参照
      tools: [ // 対応するツールを指定
        'minecraft:wooden_axe',
        'minecraft:stone_axe',
        'minecraft:iron_axe',
        'minecraft:golden_axe',
        'minecraft:diamond_axe',
        'minecraft:netherite_axe'
      ]
    },
    { id: "minecraft:log", data: [1, 5, 9], type: "log", tools: axe },
    { id: "minecraft:log", data: [2, 6, 10], type: "log", tools: axe },
    { id: "minecraft:log", data: [3, 7, 11], type: "log", tools: axe },
    { id: "minecraft:log2", data: [0, 2, 4], type: "log", tools: axe },
    { id: "minecraft:log2", data: [1, 3, 5], type: "log", tools: axe },
    { id: "minecraft:crimson_stem", data: [0, 1, 2], type: "log", tools: axe },
    { id: "minecraft:warped_stem", data: [0, 1, 2], type: "log", tools: axe },
    { id: "minecraft:mangrove_log", data: [0, 1, 2], type: "log", combi: "mangrove", tools: axe },
    { id: "minecraft:mangrove_roots", data: 0, type: "log", combi: "mangrove", tools: axe },

    {
      id: "minecraft:stone",
      lootId: "minecraft:cobblestone",
      type: "stone",
      combi: "stone",
      data: 0,
      enchant: {
        fortune: false,
        SilkTouch: true
      },
      tools: pickaxe_tier_1
    },
    {
      id: "minecraft:deepslate",
      lootId: "minecraft:cobbled_deepslate",
      type: "stone",
      combi: "stone",
      data: 0,
      enchant: {
        fortune: false,
        SilkTouch: true
      },
      tools: pickaxe_tier_1
    },
    { // *←がついている場所は必須項目です。
      id: "minecraft:coal_ore", // * 対応させるブロック名を記入。
      SubId: "minecraft:coal_ore", // 発行したレッドストーンなど、対象が２つになった場合はこちらを利用してください。
      lootId: "minecraft:coal", // * ドロップするアイテム名です。
      type: "defl", // * 壊れ方の指定 defl log stone の三種類があります。 下のmodeを参照
      combi: "coal", // コンビ名 コンビ名が同じブロックがつながっていた場合一緒に壊れます。対象が3つ以上の時に使えます。
      data: 0, // * データ値
      enchant: { // エンチャント効果の有無
        fortune: true, //幸運
        SilkTouch: true //シルクタッチ
      },
      tools: pickaxe_tier_1 // * 対応するツールを指定 上を参照してください
    },
    {
      id: "minecraft:deepslate_coal_ore",
      lootId: "minecraft:coal",
      type: "defl",
      combi: "coal",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_1
    },
    {
      id: "minecraft:iron_ore",
      lootId: "minecraft:raw_iron",
      type: "defl",
      combi: "iron",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_2
    },
    {
      id: "minecraft:deepslate_iron_ore",
      lootId: "minecraft:raw_iron",
      type: "defl",
      combi: "iron",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_2
    },
    {
      id: "minecraft:copper_ore",
      lootId: "minecraft:raw_copper",
      count: [2, 5],
      type: "defl",
      combi: "copper",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_2
    },
    {
      id: "minecraft:deepslate_copper_ore",
      lootId: "minecraft:raw_copper",
      count: [2, 5],
      type: "defl",
      combi: "copper",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_2
    },
    {
      id: "minecraft:gold_ore",
      lootId: "minecraft:raw_gold",
      type: "defl",
      combi: "gold",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_3
    },
    {
      id: "minecraft:deepslate_gold_ore",
      lootId: "minecraft:raw_gold",
      type: "defl",
      combi: "gold",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_3
    },
    {
      id: "minecraft:redstone_ore",
      SubId: "minecraft:lit_redstone_ore",
      lootId: "minecraft:redstone",
      count: [4, 5],
      type: "defl",
      combi: "redstone",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_3
    },
    {
      id: "minecraft:deepslate_redstone_ore",
      SubId: "minecraft:lit_deepslate_redstone_ore",
      lootId: "minecraft:redstone",
      count: [4, 5],
      type: "defl",
      combi: "redstone",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_3
    },
    {
      id: "minecraft:lapis_ore",
      lootId: "minecraft:lapis_lazuli",
      count: [4, 9],
      type: "defl",
      combi: "lapis",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_2
    },
    {
      id: "minecraft:deepslate_lapis_ore",
      lootId: "minecraft:lapis_lazuli",
      count: [4, 9],
      type: "defl",
      combi: "lapis",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_2
    },
    {
      id: "minecraft:diamond_ore",
      lootId: "minecraft:diamond",
      type: "defl",
      combi: "diamond",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_3
    },
    {
      id: "minecraft:deepslate_diamond_ore",
      lootId: "minecraft:diamond",
      type: "defl",
      combi: "diamond",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_3
    },
    {
      id: "minecraft:emerald_ore",
      lootId: "minecraft:emerald",
      type: "defl",
      combi: "emerald",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_3
    },
    {
      id: "minecraft:deepslate_emerald_ore",
      lootId: "minecraft:emerald",
      type: "defl",
      combi: "emerald",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_3
    },
    {
      id: "minecraft:quartz_ore",
      lootId: "minecraft:quartz",
      type: "defl",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_1
    },
    {
      id: "minecraft:nether_gold_ore",
      lootId: "minecraft:gold_nugget",
      count: [2, 6],
      type: "defl",
      data: 0,
      enchant: {
        fortune: true,
        SilkTouch: true
      },
      tools: pickaxe_tier_1
    },
    {
      id: "minecraft:obsidian",
      type: "defl",
      data: 0,
      tools: pickaxe_tier_4
    },
    {
      id: "minecraft:ancient_debris",
      type: "defl",
      data: 0,
      tools: pickaxe_tier_4
    }
  ],
  mode: [
    {
      name: 'log',
      pos: [
        { x: 1, y: 0, z: 0 },
        { x: 0, y: 0, z: 1 },
        { x: -1, y: 0, z: 0 },
        { x: 0, y: 0, z: -1 },

        { x: 1, y: 1, z: 1 },
        { x: 1, y: 1, z: -1 },
        { x: -1, y: 1, z: 1 },
        { x: -1, y: 1, z: -1 },

        { x: 1, y: 1, z: 0 },
        { x: 0, y: 1, z: 1 },
        { x: 0, y: 1, z: 0 },
        { x: -1, y: 1, z: 0 },
        { x: 0, y: 1, z: -1 },

        { x: 0, y: -1, z: 0 }
      ]
    },
    {
      name: 'defl',
      pos: [
        { x: 1, y: 0, z: 0 },
        { x: 0, y: 0, z: 1 },
        { x: -1, y: 0, z: 0 },
        { x: 0, y: 0, z: -1 },
        { x: 0, y: 1, z: 0 },
        { x: 0, y: -1, z: 0 }
      ]
    },
    {
      name: 'stone',
      limit: 2,
      pos: [
        { x: 1, y: 0, z: 0 },
        { x: 0, y: 0, z: 1 },
        { x: -1, y: 0, z: 0 },
        { x: 0, y: 0, z: -1 },
        { x: 0, y: 1, z: 0 },
        { x: 0, y: -1, z: 0 }
      ]
    }
  ]
};

const Settings = {
  DefaultSetting: {
    all: false,
    sneak: true,
    aggregation: true,
    collect: true,
    combi: true,
    pala: false,
    limitArea: 2,
    breakSpeed: 4,
    breakStack: 1,
    openMenuTool: "minecraft:stick"
  }
};


export { block_config, Settings }