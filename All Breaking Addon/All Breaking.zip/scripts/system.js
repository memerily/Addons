import { block_config, Settings } from "./config.js";
import { ModalFormData } from "mojang-minecraft-ui";
import {
    world,
    BlockLocation,
    ItemStack,
    Items,
    MinecraftEnchantmentTypes as EnchantmentTypes,
    MinecraftEntityTypes,
    DynamicPropertiesDefinition
} from "mojang-minecraft";


function TemPos(m, b) {
    let p = [];
    block_config.mode.forEach(Emode => {
        if (m === Emode.name) {
            Emode.pos.forEach(Epos => {
                const po = {
                    x: Epos.x + b.x,
                    y: Epos.y + b.y,
                    z: Epos.z + b.z
                }
                p.push(po);
            });
        }
    });
    return p;
}

function random(num, sub = 1) {
    if (Array.isArray(num)) {
        return Math.floor((Math.random() * (num[0] + 1 - num[1])) + num[1]);
    } else if (num < 1) {
        return num;
    } else {
        return Math.floor((Math.random() * (num + 1 - sub)) + sub);
    }
};

function fortune(l) { let d = [], a = "", s = 0, c = 0; d.push(Math.floor(2 / (l + 2) * 100)); for (let i = 0; i < l; i++) d.push(Math.floor(1 / (l + 2) * 100)); for (const n of d) s += n; const r = Math.floor(Math.random() * s); s = 0; for (const n of d) { s += n; if (s > r) { a = c; break; } c++ }; return a + 1; };
function block_data(l) { let e = [], t = []; for (const u of l) e.push(u.validValues.indexOf(u.value)), t.push(u.validValues.length); t.shift(), t.push(1); let u = 1; for (let l = 0; l < e.length; l++)u += e[l] * t[l]; return u - 1 };







let DATA = [];

world.events.worldInitialize.subscribe(ev => {
    console.error("§aStarting now ...");
    const data = new DynamicPropertiesDefinition();
    data.defineString("BreakAllSettingData", 500);
    ev.propertyRegistry.registerEntityTypeDynamicProperties(data, MinecraftEntityTypes.player);
})

world.events.playerJoin.subscribe(ev => {
    const { player } = ev;
    if (player.getDynamicProperty("BreakAllSettingData") == undefined) {
        player.setDynamicProperty("BreakAllSettingData", JSON.stringify(Settings.DefaultSetting));
    }
});

world.events.beforeChat.subscribe(ev => {
    const { message, sender } = ev;
    let msg = message.split(' ');
    const cmd = msg[0];
    msg.shift();
    const option = msg;
    if (cmd.startsWith("b!")) {
        ev.cancel = true;
        let text = "";
        const error = "§cCommand error.";

        if (cmd === "b!help") {
            if (!option[0]) {
                text = [
                    "§2--- Commands help ---§r",
                    "b!help",
                    "b!help [command: CommandName]",
                    "b!itemid",
                    "b!setting [mode: ModeName] [On/Off: Boolean]",
                    "b!setting [mode: ModeName] [text: String]",
                    "b!setting [mode: ModeName] [number: Number]",
                    "§2---------------------§r"
                ].join("\n");
            }
            if (option[0] === "help") {
                text += [
                    "§eb!help:",
                    "Provides help/list of commands.",
                    "§rUsage:",
                    "- b!help",
                    "- b!help [command: CommandName]"
                ].join("\n");
            }
            if (option[0] === "info") {
                text += [
                    "§eb!itemid:",
                    "Shows the ID of the item you have.",
                    "§rUsage:",
                    "- b!itemid"
                ].join("\n");
            }
            if (option[0] === "setting") {
                text += [
                    "§eb!setting:",
                    "Change the 'Break All' setting.",
                    "§rUsage:",
                    "- b!setting [mode: ModeName] [On/Off: Boolean]",
                    "- b!setting [mode: ModeName] [text: String]",
                    "- b!setting [mode: ModeName] [number: Number]",
                ].join("\n");
            }
        }
        if (cmd === "b!itemid") {
            text = sender.getComponent("inventory").container.getItem(sender.selectedSlot)?.id;
        }
        if (cmd === "b!setting") {
            let setting = JSON.parse(sender.getDynamicProperty("BreakAllSettingData"));
            if (option[0] in setting) {
                let q = JSON.parse(option[1])
                setting[option[0]] = q;
            } else if (option[0] === "reset") {
                sender.removeDynamicProperty("BreakAllSettingData");
                sender.setDynamicProperty("BreakAllSettingData", JSON.stringify(Settings.DefaultSetting));
            } else {
                text = "§2--- Break All §bSsettings §2---§r\n"
                let settingNames = [];
                Object.entries(setting).forEach(x => {
                    settingNames.push(x)
                });

                for (const data of settingNames) {
                    text += `- §b${data[0]}§r: ${(typeof data[1] === 'number') ? "§6" : data[1] ? "§d" : "§9"}${JSON.stringify(data[1]).replace(/"/g, '§r\\"§a')}§r\n`;
                }
            }
            sender.setDynamicProperty("BreakAllSettingData", JSON.stringify(setting))
        }
        sender.runCommand(`tellraw @s {"rawtext":[{"text":"${text}"}]}`)
    }
});


world.events.blockBreak.subscribe(ev => {
    const { block, brokenBlockPermutation, player, dimension } = ev;
    const setting = JSON.parse(player.getDynamicProperty("BreakAllSettingData"));
    if (!setting.all) return;
    if (!player.isSneaking && setting.sneak) return;

    const item = player.getComponent("inventory").container.getItem(player.selectedSlot);
    const hasItem = item?.id;
    if (!hasItem) return;
    const block_name = brokenBlockPermutation.type.id;
    const BD = block_data(brokenBlockPermutation.getAllProperties());
    const blockData = block_config.blocks.find(s =>
        (s.id === block_name || s.SubId === block_name) &&
        (Array.isArray(s.data) ? s.data : [s.data]).includes(BD) &&
        s.tools.includes(hasItem)
    )

    if (!blockData) return;
    let enchantData = { presence: false, id: "", level: 0 };
    const { enchantments } = item.getComponent('enchantments');
    for (const enchantType of Object.values(EnchantmentTypes)) {
        if (!enchantments.hasEnchantment(enchantType)) continue;
        const { level, type: { id } } = enchantments.getEnchantment(enchantType);
        if (id === "fortune" || id === "silkTouch") enchantData.presence = true, enchantData.id = id, enchantData.level = level;
    }
    DATA.push({
        BlockData: {
            StartBlock: block.location,
            data: blockData
        },
        PlayerData: {
            player: player,
            setting: JSON.parse(player.getDynamicProperty("BreakAllSettingData"))
        },
        Dimension: dimension,
        EnchantData: enchantData,
    });
});


let DATAS = [];
let POS = [];
let count = 0;
let tick = 0;
world.events.tick.subscribe(t => {
    try {
        if (DATA.length) {
            const { BlockData, PlayerData, Dimension, EnchantData } = DATA[0];
            const dotiledrops = JSON.parse(Dimension.runCommand(`gamerule dotiledrops`).details).dotiledrops;
    
            const limitpos = {
                max: {
                    x: BlockData.StartBlock.x + PlayerData.setting.limitArea,
                    y: BlockData.StartBlock.y + PlayerData.setting.limitArea,
                    z: BlockData.StartBlock.z + PlayerData.setting.limitArea
                },
                min: {
                    x: BlockData.StartBlock.x - PlayerData.setting.limitArea,
                    y: BlockData.StartBlock.y - PlayerData.setting.limitArea,
                    z: BlockData.StartBlock.z - PlayerData.setting.limitArea
                }
            };
    
            function ScanBlock(P, mode) {
                for (const pos of TemPos(mode, P)) {
                    const block = Dimension.getBlock(new BlockLocation(pos.x, pos.y, pos.z))
                    const combi = block_config.blocks.filter(s => s.combi === BlockData.data.combi);
                    const blockValue = block_data(block.permutation.getAllProperties());
                    const blockData = block_config.blocks.find(s =>
                        (s.id === block.id || s.SubId === block.id) &&
                        (Array.isArray(s.data) ? s.data : [s.data]).includes(blockValue)
                    )
                    if (
                        (
                            block.id === BlockData.data.id ||
                            block.SubId === BlockData.data.id ||
                            combi.some(v => (v.id === block.id || v.SubId === block.id))
                        ) &&
                        (Array.isArray(BlockData.data.data) ? BlockData.data.data : [BlockData.data.data]).includes(blockValue) &&
                        !POS.some(e => e.x === pos.x && e.y === pos.y && e.z === pos.z) &&
                        [pos].some(e => e.x <= limitpos.max.x && e.y <= limitpos.max.y && e.z <= limitpos.max.z) &&
                        [pos].some(e => e.x >= limitpos.min.x && e.y >= limitpos.min.y && e.z >= limitpos.min.z)
                    ) {
                        POS.push(pos)
                        DATAS.push(blockData)
                    }
                }
                count++;
            }
            function cmd(command, shaft = Dimension) { try { shaft.runCommand(command); } catch { } }
            function lootItem(data, pos) {
                // pprint(data)
                let F_count = 1;
                if (!data) return false;
                let lootId = data.id;
                const blockValue = Array.isArray(data.data) ? data.data[0] : data.data;
                if ("lootId" in data) lootId = data.lootId;
                if ("count" in data && !(EnchantData.id === "silkTouch" && data.enchant.SilkTouch)) F_count = random(data.count);
                if (F_count === 0) return;
                if (EnchantData.presence && "enchant" in data) {
                    if (EnchantData.id === "fortune" && data.enchant.fortune) {
                        F_count *= fortune(EnchantData.level)
                    } else
                        if (EnchantData.id === "silkTouch" && data.enchant.SilkTouch) {
                            lootId = data.id;
                        }
                }
                Dimension.spawnItem(new ItemStack(Items.get(lootId), F_count, blockValue), new BlockLocation(pos.x, pos.y, pos.z));
            };
            function BreakBlock(data, Pos) {
                let c = 0;
                for (const pos of Pos) {
                    cmd(`setblock ${pos.x} ${pos.y} ${pos.z} air`);
                    if (dotiledrops) lootItem(data[c], pos);
                    if (PlayerData.setting.aggregation) cmd(`tp @e[type=item,x=${pos.x},y=${pos.y},z=${pos.z},r=1.5] ${BlockData.StartBlock.x} ${BlockData.StartBlock.y} ${BlockData.StartBlock.z}`);
                    if (PlayerData.setting.collect) cmd(`tp @e[type=item,x=${BlockData.StartBlock.x},y=${BlockData.StartBlock.y},z=${BlockData.StartBlock.z},r=1.5] @s`, PlayerData.player);
                    c++;
                }
                c = 0;
            }
    
            if (count === 0) return ScanBlock(BlockData.StartBlock, BlockData.data.type);
            if (!POS.length && !DATAS.length) return DATA.shift(), count = 0;
            if (tick % PlayerData.setting.breakSpeed === 0) {
                let co = 0;
                while (co < PlayerData.setting.breakStack) {
                    if (!POS.length) break;
                    co++;
                    BreakBlock(DATAS, POS);
                    const data = POS;
                    POS = [];
                    DATAS = [];
                    for (const pos of data) ScanBlock(pos, BlockData.data.type);
                }
                co = 0;
            }
        }
        tick++;
    } catch (error) {
        
    }
});





world.events.beforeItemUse.subscribe(ev => {
    const { source, item } = ev;
    let setting = JSON.parse(source.getDynamicProperty("BreakAllSettingData"));
    if (item.id === setting.openMenuTool) {
        if (source.isSneaking) {
            const form = new ModalFormData().title("§l§2Break All §fSetting")
                .toggle("General", setting.all)
                .toggle("Sneaking", setting.sneak)
                .toggle("Auto aggregation", setting.aggregation)
                .toggle("Auto collect", setting.collect)
                .toggle("Combi Block", setting.combi)
                .toggle("( ᐛ )", setting.pala)
                .slider("Limit Area", 0, 32, 1, setting.limitArea)
                .slider("Breaking Speed", 0, 20, 1, setting.breakSpeed)
                .slider("Break Stack", 1, 20, 1, setting.breakStack)
                .textField("Open Menu Tool", "例) minecraft:stick", setting.openMenuTool);
            form.show(source).then(res => {
                if (res.isCanceled) return;
                const values = res.formValues;
                let settings = [];
                Object.entries(setting).forEach(x => {
                    settings.push(x)
                });
                let c = 0;
                for (const data of settings) {
                    setting[data[0]] = values[c]
                    c++;
                }
                c = 0;
                source.setDynamicProperty("BreakAllSettingData", JSON.stringify(setting))
            });

        } else {
            const form = new ModalFormData().title("§l§2Break All §fQuick Setting")
                .toggle("General", setting.all)
                .toggle("Auto aggregation", setting.aggregation)
                .toggle("Auto collect", setting.collect)
                .slider("Limit Area", 0, 32, 1, setting.limitArea)
                .slider("Breaking Speed", 0, 20, 1, setting.breakSpeed)
                .slider("Break Stack", 1, 20, 1, setting.breakStack)
                .show(source).then(res => {
                    if (res.isCanceled) return;
                    const values = res.formValues;
                    setting.all = values[0]
                    setting.aggregation = values[1]
                    setting.collect = values[2]
                    setting.limitArea = values[3]
                    setting.breakSpeed = values[4]
                    setting.breakStack = values[5]
                    source.setDynamicProperty("BreakAllSettingData", JSON.stringify(setting))
                });
        }
    }
});